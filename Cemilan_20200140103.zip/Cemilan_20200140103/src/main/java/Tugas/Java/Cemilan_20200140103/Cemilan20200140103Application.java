package Tugas.Java.Cemilan_20200140103;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cemilan20200140103Application {

	public static void main(String[] args) {
		SpringApplication.run(Cemilan20200140103Application.class, args);
	}

}
