/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tugas.Java.Cemilan_20200140103;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *
 * @author Wiratama
 */

public class Controller {
    
    @RequestMapping("/table")
    @ResponseBody
    public String getTable(Model tiki){
        String result = "";
        tiki.addAttribute("expedisi", result);
        
       
        ArrayList<List<String>> data = new ArrayList<>();
        
        data.add(0,Arrays.asList("No.","Nama Sayur","Harga PerKilo","Jumlah Beli","Tunai"));
        data.add(1,Arrays.asList("1.","Kangkung","15.000","1","15.000"));
        data.add(2,Arrays.asList("2.","Sawi","15.000","2","15.000"));
        
        tiki.addAttribute("tabel", data);
                
        return "tableview";
    }
    
    @RequestMapping("/input")
    public String getInput(HttpServletRequest data, Model model) throws ParseException{
        String result = "";
        String getNama = data.getParameter("var_A");
        
        model.addAttribute("result");
        
        return "tabelview";
    
    }
    
    
}
