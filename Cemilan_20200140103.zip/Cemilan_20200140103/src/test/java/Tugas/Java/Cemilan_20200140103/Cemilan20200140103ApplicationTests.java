package Tugas.Java.Cemilan_20200140103;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cemilan20200140103ApplicationTests {

	@Test
	void contextLoads() {
	}

}
